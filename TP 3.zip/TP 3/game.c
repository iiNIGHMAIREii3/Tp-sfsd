#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"

Game* gameList = NULL;
int gameCount = 0;

void createGame(int gameID, char* title, float price) {
    gameList = realloc(gameList, (gameCount + 1) * sizeof(Game));
    gameList[gameCount].gameID = gameID;
    strcpy(gameList[gameCount].title, title);
    gameList[gameCount].price = price;
    gameCount++;
}

void displayAllGames() {
    if (gameCount == 0) {
        printf("No games available.\n");
    } else {
        for (int i = 0; i < gameCount; i++) {
            printf("Game ID: %d, Title: %s, Price: %.2f\n", gameList[i].gameID, gameList[i].title, gameList[i].price);
        }
    }
}

void saveGamesToFile() {
    FILE* file = fopen("games.dat", "wb");
    if (file == NULL) {
        printf("Error opening games file for writing.\n");
        return;
    }
    fwrite(&gameCount, sizeof(int), 1, file); // Save the count first
    fwrite(gameList, sizeof(Game), gameCount, file); // Save the game list
    fclose(file);
}

void loadGamesFromFile() {
    FILE* file = fopen("games.dat", "rb");
    if (file == NULL) {
        printf("No game data file found. Starting with an empty game list.\n");
        return;
    }
    fread(&gameCount, sizeof(int), 1, file); // Load the count first
    gameList = malloc(gameCount * sizeof(Game));
    fread(gameList, sizeof(Game), gameCount, file); // Load the game list
    fclose(file);
}
