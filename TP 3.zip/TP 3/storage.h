#ifndef STORAGE_H
#define STORAGE_H

#include "rental.h"

// Function prototypes for storage operations
void saveRentalBlockToFile(Rental* rentalList, int rentalCount);
void loadRentalBlockFromFile(Rental** rentalList, int* rentalCount);

#endif // STORAGE_H
