#ifndef RENTAL_H
#define RENTAL_H

// Define the Rental structure
typedef struct {
    int customerID;
    int gameID;
    int rentalDays;
} Rental;

// Function prototypes
void createRental(int customerID, int gameID, int rentalDays);
Rental* searchRental(int customerID, int gameID);
void displayAllRentals();
void printRental(Rental* rental);
void loadRentalsFromFile();
void saveRentalsToFile();

#endif // RENTAL_H
