#include <stdio.h>
#include "storage.h"

// Function to save rentals to a file
void saveRentalBlockToFile(Rental* rentalList, int rentalCount) {
    FILE* file = fopen("rentals.dat", "wb");
    if (file != NULL) {
        fwrite(&rentalCount, sizeof(int), 1, file);
        fwrite(rentalList, sizeof(Rental), rentalCount, file);
        fclose(file);
    }
}

// Function to load rentals from a file
void loadRentalBlockFromFile(Rental** rentalList, int* rentalCount) {
    FILE* file = fopen("rentals.dat", "rb");
    if (file != NULL) {
        fread(rentalCount, sizeof(int), 1, file);
        *rentalList = malloc(*rentalCount * sizeof(Rental));
        fread(*rentalList, sizeof(Rental), *rentalCount, file);
        fclose(file);
    }
}
