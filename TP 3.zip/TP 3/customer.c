#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "customer.h"

Customer* customerList = NULL;
int customerCount = 0;

void createCustomer(int customerID, char* name) {
    customerList = realloc(customerList, (customerCount + 1) * sizeof(Customer));
    customerList[customerCount].customerID = customerID;
    strcpy(customerList[customerCount].name, name);
    customerCount++;
}

void displayAllCustomers() {
    if (customerCount == 0) {
        printf("No customers available.\n");
    } else {
        for (int i = 0; i < customerCount; i++) {
            printf("Customer ID: %d, Name: %s\n", customerList[i].customerID, customerList[i].name);
        }
    }
}

void saveCustomersToFile() {
    FILE* file = fopen("customers.dat", "wb");
    if (file == NULL) {
        printf("Error opening customers file for writing.\n");
        return;
    }
    fwrite(&customerCount, sizeof(int), 1, file); // Save the count first
    fwrite(customerList, sizeof(Customer), customerCount, file); // Save the customer list
    fclose(file);
}

void loadCustomersFromFile() {
    FILE* file = fopen("customers.dat", "rb");
    if (file == NULL) {
        printf("No customer data file found. Starting with an empty customer list.\n");
        return;
    }
    fread(&customerCount, sizeof(int), 1, file); // Load the count first
    customerList = malloc(customerCount * sizeof(Customer));
    fread(customerList, sizeof(Customer), customerCount, file); // Load the customer list
    fclose(file);
}
