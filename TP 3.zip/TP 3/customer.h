#ifndef CUSTOMER_H
#define CUSTOMER_H

typedef struct {
    int customerID;
    char name[50];
} Customer;

void createCustomer(int customerID, char* name);
void displayAllCustomers();

#endif
