#ifndef GAME_H
#define GAME_H

typedef struct {
    int gameID;
    char title[50];
    float price;
} Game;

void createGame(int gameID, char* title, float price);
void displayAllGames();

#endif
