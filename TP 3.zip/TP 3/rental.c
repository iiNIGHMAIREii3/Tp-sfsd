#include <stdio.h>
#include <stdlib.h>
#include "rental.h"

// A simple rental list to store rental data
Rental* rentalList = NULL;
int rentalCount = 0;

// Function to create a new rental
void createRental(int customerID, int gameID, int rentalDays) {
    rentalList = realloc(rentalList, (rentalCount + 1) * sizeof(Rental));
    rentalList[rentalCount].customerID = customerID;
    rentalList[rentalCount].gameID = gameID;
    rentalList[rentalCount].rentalDays = rentalDays;
    rentalCount++;
}

// Function to search for a rental by customerID
Rental* searchRentalByCustomerID(int customerID) {
    for (int i = 0; i < rentalCount; i++) {
        if (rentalList[i].customerID == customerID) {
            return &rentalList[i];
        }
    }
    return NULL;
}

// Function to search for a rental by gameID
Rental* searchRentalByGameID(int gameID) {
    for (int i = 0; i < rentalCount; i++) {
        if (rentalList[i].gameID == gameID) {
            return &rentalList[i];
        }
    }
    return NULL;
}

// Function to display all rentals
void displayAllRentals() {
    for (int i = 0; i < rentalCount; i++) {
        printRental(&rentalList[i]);
    }
}

// Function to print a rental's details
void printRental(Rental* rental) {
    if (rental != NULL) {
        printf("Customer ID: %d | Game ID: %d | Rental Days: %d\n",
               rental->customerID, rental->gameID, rental->rentalDays);
    }
}

// Function to load rentals from a file
void loadRentalsFromFile() {
    FILE* file = fopen("rentals.dat", "rb");
    if (file != NULL) {
        fread(&rentalCount, sizeof(int), 1, file);
        rentalList = malloc(rentalCount * sizeof(Rental));
        fread(rentalList, sizeof(Rental), rentalCount, file);
        fclose(file);
    }
}

// Function to save rentals to a file
void saveRentalsToFile() {
    FILE* file = fopen("rentals.dat", "wb");
    if (file != NULL) {
        fwrite(&rentalCount, sizeof(int), 1, file);
        fwrite(rentalList, sizeof(Rental), rentalCount, file);
        fclose(file);
    }
}
