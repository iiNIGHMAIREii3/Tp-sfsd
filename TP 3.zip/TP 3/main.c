#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rental.h"
#include "storage.h"
#include "customer.h"
#include "game.h"

int main() {
    int choice;
    int customerID, gameID, rentalDays, searchChoice;
    char customerName[50];
    char gameTitle[50];
    float gamePrice;

    // Main menu loop
    while (1) {
        printf("\nRental System Menu:\n");
        printf("1. Create a Rental\n");
        printf("2. Display All Rentals\n");
        printf("3. Search for a Rental\n");
        printf("4. Create a Customer\n");
        printf("5. Create a Game\n");
        printf("6. Display All Customers\n");
        printf("7. Display All Games\n");
        printf("8. Load Costumers/Games/Rentals Data\n");
        printf("9. Save and Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // Clear the newline character from the buffer after scanf

        switch (choice) {
            case 1:
                // Create a rental
                printf("Enter customer ID: ");
                scanf("%d", &customerID);
                printf("Enter game ID: ");
                scanf("%d", &gameID);
                printf("Enter rental days: ");
                scanf("%d", &rentalDays);
                createRental(customerID, gameID, rentalDays);
                break;

            case 2:
                // Display all rentals
                displayAllRentals();
                break;

            case 3:
                // Search for a rental
                printf("Search by:\n");
                printf("1. Customer ID\n");
                printf("2. Game ID\n");
                printf("Enter your choice: ");
                scanf("%d", &searchChoice);

                if (searchChoice == 1) {
                    printf("Enter customer ID: ");
                    scanf("%d", &customerID);
                    Rental* rental = searchRentalByCustomerID(customerID);
                    if (rental != NULL) {
                        printf("Rental found: ");
                        printRental(rental);
                    } else {
                        printf("Rental not found for customer ID %d.\n", customerID);
                    }
                } else if (searchChoice == 2) {
                    printf("Enter game ID: ");
                    scanf("%d", &gameID);
                    Rental* rental = searchRentalByGameID(gameID);
                    if (rental != NULL) {
                        printf("Rental found: ");
                        printRental(rental);
                    } else {
                        printf("Rental not found for game ID %d.\n", gameID);
                    }
                } else {
                    printf("Invalid choice. Please try again.\n");
                }
                break;

            case 4:
                // Create a customer
                printf("Enter customer ID: ");
                scanf("%d", &customerID);
                getchar();  // Clear the newline character from the buffer
                printf("Enter customer name: ");
                fgets(customerName, sizeof(customerName), stdin);
                customerName[strcspn(customerName, "\n")] = '\0'; // Remove newline character
                createCustomer(customerID, customerName);
                break;

            case 5:
                // Create a game
                printf("Enter game ID: ");
                scanf("%d", &gameID);
                getchar();  // Clear the newline character from the buffer
                printf("Enter game title: ");
                fgets(gameTitle, sizeof(gameTitle), stdin);
                gameTitle[strcspn(gameTitle, "\n")] = '\0'; // Remove newline character
                printf("Enter game price: ");
                scanf("%f", &gamePrice);
                createGame(gameID, gameTitle, gamePrice);
                break;

            case 6:
                // Display all customers
                displayAllCustomers();
                break;

            case 7:
                // Display all games
                displayAllGames();
                break;

            case 8:
                // Load rentals data
                loadRentalsFromFile();

                // Load customers data
                loadCustomersFromFile();

                // Load games data
                loadGamesFromFile();
                printf("Games /costumers / rentals data loaded.\n");
                break;

            case 9:
                // Save data to files and exit
                saveRentalsToFile();
                saveCustomersToFile();
                saveGamesToFile();
                printf("Data saved. Exiting...\n");
                return 0;

            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }
    }

    return 0;
}
